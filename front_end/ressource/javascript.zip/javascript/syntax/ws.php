<?php

echo 'OK';

?>