<?php
//sleep(10);
echo file_get_contents('data.json');

?>


