
function Vehicule(){}

Vehicule.prototype._serial = 01234567489;